/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package phonebook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * @author Renzo Pretto
 */
public class WriterAndReader {

    public static ObservableList<Person> readPersonInfo() throws FileNotFoundException{
    
        ObservableList<Person> list = FXCollections.observableArrayList();
        
        File file;
        file = new File("Contacts.txt");
        File file2;
        file2 = new File("ContactKeys.txt");
        Scanner sc = new Scanner(file);
        Scanner sc2 = new Scanner(file2);
        String s = "";
        int counter = 0;
        String firstName = " ", middleName = " ", lastName = " ", homePhone = " ", mobilePhone = " ", workPhone = " ",
            country = " ", state = " ", city = " ", zipCode = " ", address = " ", personalEmail = " ", workEmail = " ", schoolEmail = " ", birthday = " ", key = " ";
        while (sc.hasNextLine()) {
            firstName = sc.nextLine();
            middleName = sc.nextLine();
            lastName = sc.nextLine();
            homePhone = sc.nextLine();
            mobilePhone = sc.nextLine();
            workPhone = sc.nextLine();
            country = sc.nextLine();
            state = sc.nextLine();
            city = sc.nextLine();
            zipCode = sc.nextLine();
            address = sc.nextLine();
            personalEmail = sc.nextLine();
            workEmail = sc.nextLine();
            schoolEmail = sc.nextLine();
            key = sc2.nextLine();
            list.add(new Person(firstName, middleName, lastName, homePhone, mobilePhone,
            workPhone, country, state, city, zipCode, address, personalEmail, workEmail, schoolEmail, key));
        }
        
        return list;
    }
    
    public static void writePersonInfo(ObservableList<Person> list, int maxInt) throws Exception {
        
        Scanner kb = new Scanner(System.in);
        
        PrintWriter writer = new PrintWriter("Contacts.txt");
        PrintWriter writer2 = new PrintWriter("ContactKeys.txt");
        PrintWriter writer3 = new PrintWriter("settings.txt");
        
        for (int i = 0; i < list.size(); i++) {
            writer.println(list.get(i).getFirstName());
            writer.println(list.get(i).getMiddleName());
            writer.println(list.get(i).getLastName());
            writer.println(list.get(i).getHomePhone());
            writer.println(list.get(i).getMobilePhone());
            writer.println(list.get(i).getWorkPhone());
            writer.println(list.get(i).getCountry());
            writer.println(list.get(i).getState());
            writer.println(list.get(i).getCity());
            writer.println(list.get(i).getZipCode());
            writer.println(list.get(i).getAddress());
            writer.println(list.get(i).getPersonalEmail());
            writer.println(list.get(i).getWorkEmail());
            writer.println(list.get(i).getSchoolEmail());
            writer2.println(list.get(i).getKey());
        }

        writer3.println(maxInt);
        
            writer.close();
            writer2.close();
            writer3.close();
        
    }
    
    public static int readMaxKey() throws FileNotFoundException {
        File file;
        file = new File("settings.txt");
        Scanner sc = new Scanner(file);
        int maxInt = sc.nextInt();
        
        return maxInt;
    }
    
}